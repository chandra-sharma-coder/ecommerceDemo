<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['admin/login'] = 'admin/login';
$route['admin/login_action'] = 'admin/login_action';
$route['admin/dashboard'] = 'admin/dashboard';
$route['admin/add_product'] = 'admin/add_product';
$route['admin/add_product_action'] = 'admin/add_product_action';
$route['admin/edit_product/(:num)'] = 'admin/edit_product/$1';
$route['admin/edit_product_action/(:num)'] = 'admin/edit_product_action/$1';
$route['admin/delete_product/(:num)'] = 'admin/delete_product/$1';

$route['user/login'] = 'user/login';
$route['user/login_action'] = 'user/login_action';
$route['user/dashboard'] = 'user/dashboard';
$route['user/add_to_cart/(:num)'] = 'user/add_to_cart/$1';
$route['user/cart'] = 'user/cart';
$route['user/update_cart_item/(:num)'] = 'user/update_cart_item/$1';
$route['user/delete_cart_item/(:num)'] = 'user/delete_cart_item/$1';


$route['api/orders'] = 'order_api/orders';
$route['api/order/(:num)'] = 'order_api/order/$1';