<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['rest_default_format'] = 'json';
$config['rest_enable_keys'] = FALSE;
$config['rest_auth'] = 'basic'; // You can use 'basic' or 'digest'
$config['rest_ip_whitelist'] = [];
$config['rest_ip_blacklist'] = [];
$config['rest_allow_any_cors'] = FALSE;
$config['rest_cors_allowed_origins'] = [];
$config['rest_enable_cors'] = FALSE;
$config['rest_enable_log'] = TRUE;
$config['rest_log_path'] = APPPATH . 'logs/rest_log';