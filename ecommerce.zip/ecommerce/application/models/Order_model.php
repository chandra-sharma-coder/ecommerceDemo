<?php
class Order_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function get_orders() {
        $this->db->select('orders.*, users.username as customer_name');
        $this->db->from('orders');
        $this->db->join('users', 'users.id = orders.user_id');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function get_order_details($order_id) {
        $this->db->select('order_details.*, products.name as product_name');
        $this->db->from('order_details');
        $this->db->join('products', 'products.id = order_details.product_id');
        $this->db->where('order_details.order_id', $order_id);
        $query = $this->db->get();
        return $query->result_array();
    }
}
?>
