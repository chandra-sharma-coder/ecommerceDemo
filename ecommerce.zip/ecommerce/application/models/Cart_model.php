<?php
class Cart_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function get_cart_items($user_id) {
        $this->db->select('cart.*, products.name as product_name');
        $this->db->from('cart');
        $this->db->join('products', 'products.id = cart.product_id');
        $this->db->where('cart.user_id', $user_id);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function get_cart_item($user_id, $product_id) {
        $this->db->where('user_id', $user_id);
        $this->db->where('product_id', $product_id);
        $query = $this->db->get('cart');
        return $query->row_array();
    }

    public function get_cart_item_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('cart');
        return $query->row_array();
    }

    public function add_to_cart($data) {
        return $this->db->insert('cart', $data);
    }

    public function update_cart_item($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('cart', $data);
    }

    public function delete_cart_item($id) {
        $this->db->where('id', $id);
        return $this->db->delete('cart');
    }
}
?>
