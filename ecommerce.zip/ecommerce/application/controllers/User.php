<?php
class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Product_model');
        $this->load->model('Cart_model');
    }

    public function login() {
        $this->load->view('user_login');
    }

    public function login_action() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $user = $this->User_model->login($username, $password);

        if($user) {
            $this->session->set_userdata('user_logged_in', true);
            $this->session->set_userdata('user_id', $user['id']);
            redirect('user/dashboard');
        } else {
            $this->session->set_flashdata('error', 'Invalid username or password');
            redirect('user/login');
        }
    }

    public function dashboard() {
        $data['products'] = $this->Product_model->get_products();
        $this->load->view('user_dashboard', $data);
    }

    public function add_to_cart($product_id) {
        $user_id = $this->session->userdata('user_id');
        $quantity = $this->input->post('quantity');

        // Fetch product details
        $product = $this->Product_model->get_product($product_id);

        if ($product) {
            if ($quantity > 0 && $quantity <= $product['quantity']) {
                // Check if the item is already in the cart
                $cart_item = $this->Cart_model->get_cart_item($user_id, $product_id);
                if ($cart_item) {
                    // Update quantity in the cart
                    $new_quantity = $cart_item['quantity'] + $quantity;
                    if ($new_quantity <= $product['quantity']) {
                        $this->Cart_model->update_cart_item($cart_item['id'], array('quantity' => $new_quantity));
                    } else {
                        $this->session->set_flashdata('error', 'Quantity exceeds available stock.');
                    }
                } else {
                    // Add new item to the cart
                    $data = array(
                        'user_id' => $user_id,
                        'product_id' => $product_id,
                        'quantity' => $quantity
                    );
                    $this->Cart_model->add_to_cart($data);
                }
            } else {
                $this->session->set_flashdata('error', 'Invalid quantity.');
            }
        } else {
            $this->session->set_flashdata('error', 'Product not found.');
        }
        
        redirect('user/dashboard');
    }

    public function cart() {
        $user_id = $this->session->userdata('user_id');
        $data['cart_items'] = $this->Cart_model->get_cart_items($user_id);
        $this->load->view('user_cart', $data);
    }

    public function update_cart_item($id) {
        $quantity = $this->input->post('quantity');
        $cart_item = $this->Cart_model->get_cart_item_by_id($id);

        // Fetch product details
        $product = $this->Product_model->get_product($cart_item['product_id']);

        if ($quantity > 0 && $quantity <= $product['quantity']) {
            $data = array('quantity' => $quantity);
            $this->Cart_model->update_cart_item($id, $data);
        } else {
            $this->session->set_flashdata('error', 'Quantity exceeds available stock.');
        }

        redirect('user/cart');
    }

    public function delete_cart_item($id) {
        $this->Cart_model->delete_cart_item($id);
        redirect('user/cart');
    }
}
?>
