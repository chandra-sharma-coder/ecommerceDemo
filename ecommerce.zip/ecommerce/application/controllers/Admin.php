<?php
use GuzzleHttp\Client;
class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->model('Product_model');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('curl');
    }

    public function login() {
        $this->load->view('admin_login');
    }

    public function login_action() {
        
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $admin = $this->Admin_model->login($username, $password);

        if($admin) {
            $this->session->set_userdata('admin_logged_in', true);
            redirect('admin/dashboard');
        } else {
            $this->session->set_flashdata('error', 'Invalid username or password');
            redirect('admin/login');
        }
    }

    public function dashboard() {
        $data['products'] = $this->Product_model->get_products();

        $orders = $this->curl->simple_get(site_url('api/orders'));

        $data['orders'] = json_decode($orders, true);

        $this->load->view('admin_dashboard', $data);
    }

    public function add_product() {
        $this->load->view('admin_add_product');
    }

    public function add_product_action() {
        $data = array(
            'name' => $this->input->post('name'),
            'quantity' => $this->input->post('quantity')
        );
        $this->Product_model->add_product($data);
        redirect('admin/dashboard');
    }

    public function edit_product($id) {
        $data['product'] = $this->Product_model->get_product($id);
        $this->load->view('admin_edit_product', $data);
    }

    public function edit_product_action($id) {
        $data = array(
            'name' => $this->input->post('name'),
            'quantity' => $this->input->post('quantity')
        );
        $this->Product_model->update_product($id, $data);
        redirect('admin/dashboard');
    }

    public function delete_product($id) {
        $this->Product_model->delete_product($id);
        redirect('admin/dashboard');
    }
}
?>
