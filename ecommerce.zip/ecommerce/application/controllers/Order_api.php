<?php
use Restserver\Libraries\REST_Controller;

require(APPPATH.'/libraries/REST_Controller.php');
require(APPPATH.'/libraries/Format.php');

class Order_api extends REST_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Order_model');
    }

    public function orders_get() {
        $orders = $this->Order_model->get_orders();
        if($orders) {
            foreach($orders as &$order) {
                $order['details'] = $this->Order_model->get_order_details($order['id']);
            }
            $this->response($orders, REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'No orders found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function order_get($id) {
        $order = $this->Order_model->get_orders($id);
        if($order) {
            $order['details'] = $this->Order_model->get_order_details($id);
            $this->response($order, REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Order not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
}
?>
