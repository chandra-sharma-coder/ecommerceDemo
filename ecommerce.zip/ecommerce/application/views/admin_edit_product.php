<!DOCTYPE html>
<html>

<head>
    <title>Edit Product</title>
</head>

<body>
    <h2>Edit Product</h2>
    <?php echo validation_errors(); ?>
    <?php echo form_open('admin/edit_product_action/' . $product['id']); ?>
    <label for="name">Product Name:</label>
    <input type="text" name="name" value="<?php echo $product['name']; ?>"><br>
    <label for="quantity">Quantity:</label>
    <input type="text" name="quantity" value="<?php echo $product['quantity']; ?>"><br>
    <input type="submit" value="Update Product">
    </form>
</body>

</html>