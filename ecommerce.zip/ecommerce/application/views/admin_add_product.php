<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
</head>
<body>
    <h2>Add Product</h2>
    <?php echo validation_errors(); ?>
    <?php echo form_open('admin/add_product_action'); ?>
    <label for="name">Product Name:</label>
    <input type="text" name="name"><br>
    <label for="quantity">Quantity:</label>
    <input type="text" name="quantity"><br>
    <input type="submit" value="Add Product">
    </form>
</body>
</html>
