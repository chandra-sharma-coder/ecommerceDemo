<!DOCTYPE html>
<html>
<head>
    <title>User Cart</title>
</head>
<body>
    <h2>Your Cart</h2>

    <?php if ($this->session->flashdata('error')): ?>
    <p style="color:red;"><?php echo $this->session->flashdata('error'); ?></p>
    <?php endif; ?>

    <table border="1">
        <tr>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($cart_items as $item): ?>
        <tr>
            <td><?php echo $item['product_name']; ?></td>
            <td>
                <form action="<?php echo site_url('user/update_cart_item/'.$item['id']); ?>" method="post">
                    <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1">
                    <input type="submit" value="Update">
                </form>
            </td>
            <td>
                <a href="<?php echo site_url('user/delete_cart_item/'.$item['id']); ?>">Remove</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
