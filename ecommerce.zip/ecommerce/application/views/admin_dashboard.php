<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h2>Welcome to Admin Dashboard</h2>
    <p>You are logged in as admin.</p>
    <h3>Product List</h3>
    <a href="<?php echo site_url('admin/add_product'); ?>">Add New Product</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Quantity</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($products as $product): ?>
        <tr>
            <td><?php echo $product['id']; ?></td>
            <td><?php echo $product['name']; ?></td>
            <td><?php echo $product['quantity']; ?></td>
            <td>
                <a href="<?php echo site_url('admin/edit_product/'.$product['id']); ?>">Edit</a>
                <a href="<?php echo site_url('admin/delete_product/'.$product['id']); ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>



    <h3>Orders</h3>
    <table border="1">
        <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Order Date</th>
            <th>Status</th>
            <th>Details</th>
        </tr>
        <?php foreach ($orders as $order): ?>
        <tr>
            <td><?php echo $order['id']; ?></td>
            <td><?php echo $order['customer_name']; ?></td>
            <td><?php echo $order['order_date']; ?></td>
            <td><?php echo $order['status']; ?></td>
            <td>
                <ul>
                    <?php foreach ($order['details'] as $detail): ?>
                    <li><?php echo $detail['product_name']; ?> - Quantity: <?php echo $detail['quantity']; ?></li>
                    <?php endforeach; ?>
                </ul>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

</body>
</html>
