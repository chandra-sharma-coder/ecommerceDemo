<!DOCTYPE html>
<html>

<head>
    <title>Home Page</title>
</head>

<body>
    <h2>Welcome to the Home Page</h2>
    <a href="<?php echo site_url('admin/login'); ?>">Admin Login</a><br>
    <a href="<?php echo site_url('user/login'); ?>">User Login</a>
</body>

</html>